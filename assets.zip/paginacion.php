<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

<body>

    <ul id="datos">

    </ul>

    <div id="pagination"></div>

    <script>
        let ul = document.querySelector("#datos")
        let paginador = document.querySelector('#pagination')
        let cantRegsForPage = 4
        let url = `controllers/data.show.php?cant=${cantRegsForPage}`;

        let pages = async () => {
            let results = await fetch(`controllers/data.show.php?cant=${cantRegsForPage}&pages=true`)
            let cant = await results.json();
            if(cant > 1){
                for (let i = 0; i < cant; i++) {
                    let button = document.createElement('button');
                    let page = i + 1;
                    button.textContent = page;
                    button.addEventListener('click', () => {
                        ul.textContent = '';
                        url = `controllers/data.show.php?cant=${cantRegsForPage}&page=${page}`
                        datos(url)
    
                    })
                    paginador.appendChild(button);
                }
            }
        }

        const datos = async (url) => {

            const results = await fetch(url);
            const datos = await results.json();

            console.table(datos)

            datos.forEach(e => {
                const li = document.createElement('li');
                li.textContent = e.titulo;
                ul.appendChild(li);
            });
        }

        pages();
        datos(url);
    </script>
</body>

</html>