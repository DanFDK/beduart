<?php
mb_internal_encoding("UTF-8");

$nombre = $_POST['nombre'];
$correo = $_POST['correo'];
$whatsapp = $_POST['telefono'];
$mensaje = $_POST['mensaje'];


if ($mensaje == null && $nombre == null && $whatsapp == null && $correo == null) {
    echo json_encode(false);
    exit();
}

$correoSend = "no-reply@example.com";

// Aseguramos que los datos tengan codificación UTF-8
$nombre = utf8_encode($nombre);
$correo = utf8_encode($correo);
$whatsapp = utf8_encode($whatsapp);
$mensaje = utf8_encode($mensaje);

$asunto = "$nombre solicita información";
$msg = "Teléfono: $whatsapp" . "\r\n" . "Correo: $correo" . "\r\n" . "$mensaje";
$destinatario = "$correo";
$header = "From: $correoSend" . "\r\n" .
    "Reply-To: $correoSend" . "\r\n" .
    "X-Mailer: PHP/" . phpversion() . "\r\n" .
    "Content-Type: text/plain; charset=utf-8";

$send = @mail($destinatario, $asunto, $msg, $header);

if ($send) {
    echo json_encode(true);
} else {
    echo json_encode(false);
}