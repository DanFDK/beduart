<?php
include_once('../database/conexion.php');

$user = $_POST['usuario'];
$pass = $_POST['password'];

try{
    
    $usuarios = $conexion->query("SELECT * FROM usuarios WHERE usuario = '$user'");
    
    $result = $usuarios->fetchAll(PDO::FETCH_ASSOC);
    $usuario = ($result[0]) ? $result[0] : null;

    if($usuario){
        if(password_verify($pass,$usuario['password'])){
            session_start();
            $_SESSION['usuario'] = $usuario['usuario'];
            header("Location: ../admin/");
        }
    }else{
        header("Location: ../view/login.php");
    }

}catch (PDOException $err){
    header("Location: ../view/login.php");
}

// $usuario = "Administrador";
// $password = "Admin.431";
// $hash = password_hash($password, PASSWORD_BCRYPT);

// $conexion -> query("INSERT INTO usuarios SET usuario = '$usuario', password = '$hash'");
