<?php
include_once('../database/conexion.php');


$pagina = isset($_GET['page']) ? $_GET['page'] : 1;
$cantidadData = isset($_GET['cant']) ? $_GET['cant'] : 10;
$totalRegisters = isset($_GET['pages']) ? $_GET['pages'] : null;
$categoria = isset($_GET['category']) ? $_GET['category'] : null;

$offset = ($pagina - 1) * $cantidadData;

//Para saber la cantidad de paginas hay que enviar ?pages=true por la url
if($totalRegisters){
    $consulta = $conexion->query("SELECT COUNT(*) AS total FROM galeria;");
    $resultado = $consulta->fetchAll(PDO::FETCH_ASSOC);
    $cantRegs = $resultado[0]['total'];
    $pages = $cantRegs / $cantidadData; 
        
    echo ceil($pages);
    exit();
}

//Para escoger la categoría hay que mandar el parametro category por la url: category=departamentos
if($categoria){
    $consulta = $conexion->prepare("SELECT * FROM galeria WHERE category = :category LIMIT :offset , :limit");
    $consulta->bindValue(':offset', $offset, PDO::PARAM_INT);
    $consulta->bindValue(':limit', $cantidadData, PDO::PARAM_INT);
    $consulta->bindValue(':category', $categoria, PDO::PARAM_STR);
    $consulta->execute();
    
    $resultado = $consulta->fetchAll(PDO::FETCH_ASSOC);

    $data = json_encode($resultado);
    echo $data;

    exit();
}

$consulta = $conexion->prepare("SELECT * FROM galeria LIMIT :offset , :limit");
$consulta->bindValue(':offset', $offset, PDO::PARAM_INT);
$consulta->bindValue(':limit', $cantidadData, PDO::PARAM_INT);
$consulta->execute();

$resultado = $consulta->fetchAll(PDO::FETCH_ASSOC);

$data = json_encode($resultado);

echo $data;
exit();