<?php 
include_once('../database/conexion.php');
$queryAll = "SELECT * FROM galeria";
$resultGaleria = $conexion->query($queryAll);
$dataGaleria = $resultGaleria->fetchAll(PDO::FETCH_ASSOC);

session_start();

if(!isset($_SESSION['usuario'])){
    header('Location: ../view/login.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

    <link rel="stylesheet" href="assets/css/app.css">
    <title>Panel de control</title>
</head>
<body>


<main class="galeria">
    <section class="row"> 
        <section class="galeria__gestion col-3 col-lg-2">
            <form id="formulario" action="controllers/new.image.php" method="POST" enctype="multipart/form-data" class="galeria__formulario">
                <picture>
                    <img id="imagen-placeholder" class="galeria__formulario__image" src="https://fakeimg.pl/1200x800" alt="Placeholder de la imagen">
                </picture>
                <input type="hidden" id="input-id" name="id">
                <div class="mb-3">
                    <label class="form-label" for="">Nueva imagen</label>
                    <input name="image" id="input-img" class="galeria__formulario__input form-control" type="file" placeholder="Selecciona una imagen">
                </div>
                <div class="mb-3">
                    <label class="form-label" for="">Titulo de la imagen</label>
                    <input name="titulo" id="input-titulo" class="galeria__formulario__input form-control" type="text" placeholder="Ejemplo: Fracc. Las Lomas">
                </div>
                <div class="mb-3">
                    <label class="form-label" for="">Subtitulo de la imagen</label>
                    <input name="subtitulo" id="input-subtitulo" class="galeria__formulario__input form-control" type="text" placeholder="Ejemplo: Guadalajara, Jal.">
                </div>
                <div class="mb-4 form-check form-switch galeria__formulario__switch">
                    <input name="check" id="input-check" class="form-check-input" type="checkbox" role="switch" id="flexSwitchCheckDefault">
                    <label class="form-check-label" for="flexSwitchCheckDefault">Mostrar en el carrusel</label>
                </div>

                <button id="form-submit" data-evento="0" type="submit" class="galeria__formulario__submit btn">Guardar imagen</button>
            </form>
        </section>

        <section class="galeria__seccion col-9 col-lg-10">

            <header class="position-absolute end-0 top-0">
                <form id="formLogout" class="p-5" action="../controllers/session.logout.php">
                    <button class="btn btn-outline-secondary">Cerrar Sesión</button>
                </form>
            </header>

            <h1 class="fw-bold">Tus imagenes</h1>
            <p>Personaliza las imagenes de tu slide principal y servicios</p>
            <section class="row">

            <?php foreach($dataGaleria as $data){
                $titulo = $data['titulo'];
                $subtitulo = $data['subtitulo'];
                $dir = "../" . $data['dir'];
                $banner = $data['banner'];
                $id = $data['id'];    
            ?>
        
                <article class="col-md-4 col-lg-3 galeria__seccion__img">
                    <div class="ratio ratio-1x1">
                        <picture>
                            <img class="galeria__seccion__img" src="<?= $dir ?>" alt="Imagen de prueba">
                        </picture>
                    </div>
                    <section class="galeria__seccion__desplagable">
                        <header>
                            <button onclick="actualizarImagen(this)" data-id="<?=$id?>" data-titulo="<?=$titulo?>" data-subtitulo="<?=$subtitulo?>" data-banner="<?=$banner?>" data-dir="<?=$dir?>" type="button" class="btn galeria-btn-action"><i class="bi bi-pencil-fill"></i></button>
                            <button onclick="eliminarImagen(this)" data-id="<?=$id?>" type="button" class="btn galeria-btn-action"><i class="bi bi-trash-fill"></i></button>
                        </header>
                        <section>
                            <p class="fw-bold"><?=$titulo?></p>
                            <p class=""><?=$subtitulo?></p>
                        </section>
                    </section>
                </article>

            <?php } ?>
            </section>
        </section>
    </section>

</main>

<script src="assets/scripts/gestion.images.js"></script>

</body>
</html>