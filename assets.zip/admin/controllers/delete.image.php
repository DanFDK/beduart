<?php
include_once('../../database/conexion.php');
include('../utils/move.image.php');

$id = $_GET['id'];

$queryDel = "DELETE FROM galeria WHERE id = $id";
$querySelect = "SELECT * FROM galeria WHERE id = $id";
$result = $conexion->query($querySelect);
$data = $result->fetchAll(PDO::FETCH_ASSOC);
$ruta = "../../" . $data[0]['dir'];

try{
    $conexion -> query($queryDel);
    deleteImage($ruta);
    echo true;
}catch(PDOException $err){
    echo false;
}
