<?php
include_once('../../database/conexion.php');
include('../utils/move.image.php');

$titulo = $_POST['titulo'];
$subtitulo = $_POST['subtitulo'];
$image = ($_FILES['image']['name'] != null ) ? $_FILES['image'] : null;
$check = ($_POST['check'] === "on") ? 1 : 0;

$nameImage = str_replace(" ", "", $titulo);

$ruta = moverImagen($image,$nameImage);
if($ruta != null){
    $query = "INSERT INTO galeria SET titulo='$titulo',subtitulo='$subtitulo',dir='$ruta',banner=$check";
    try{
        $conexion -> query($query);
        header("Location: ../index.php");
    }catch(PDOException $err){
        echo "Error al guardar: " . $err -> getMessage();
    }
}else{
    echo "Error al mover";
}
