<?php
include_once('../../database/conexion.php');
include('../utils/move.image.php');

$titulo = $_POST['titulo'];
$subtitulo = $_POST['subtitulo'];
$image = ($_FILES['image']['name'] != null ) ? $_FILES['image'] : null;
$check = ($_POST['check'] == "on") ? 1 : 0;
$id = $_POST['id'];
$nameImage = str_replace(" ", "", $titulo);

$querySelect = "SELECT * FROM galeria WHERE id = $id";
$result = $conexion->query($querySelect);
$data = $result->fetchAll(PDO::FETCH_ASSOC);
$rutaDelete = "../../" . $data[0]['dir'];

if($image == null){
    $query = "UPDATE galeria SET titulo='$titulo', subtitulo='$subtitulo', banner=$check WHERE id = $id";
    $conexion -> query($query);
    header('Location: ../index.php');
}else{
    $newRuta = moverImagen($image,$nameImage); 
    $query = "UPDATE galeria SET dir='$newRuta',titulo='$titulo', subtitulo='$subtitulo', banner=$check WHERE id = $id";
    $conexion -> query($query);
    
    deleteImage($rutaDelete);

    header('Location: ../index.php');
}

