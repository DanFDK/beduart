<?php 

function moverImagen($image, $titulo){
    $ruta_temp = $image['tmp_name'];
    $name_image = $image['name'];
    $extension = pathinfo($name_image, PATHINFO_EXTENSION);
    $nameFinal = $titulo . "_" . uniqid() . "." . $extension;
    $rutaDB = "uploads/" . $nameFinal;
    $rutaFinal = "../../" . $rutaDB;
    // echo $rutaFinal;
    $move = move_uploaded_file($ruta_temp, $rutaFinal);

    if($move){
        return $rutaDB;
    }else{
        return null;
    }
};

function deleteImage($ruta){
    if(file_exists($ruta)){
        unlink($ruta);
    }else{
        echo "La imagen no se encontro";
    }
}