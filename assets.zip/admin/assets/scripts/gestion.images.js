let formulario = document.querySelector('#formulario');

let imgPlaceholder = document.querySelector('#imagen-placeholder');
let inpImg = document.querySelector('#input-img');
let inpTitulo = document.querySelector('#input-titulo');
let inpSubtitulo = document.querySelector('#input-subtitulo');
let inpCheck = document.querySelector('#input-check');
let inpId = document.querySelector('#input-id');
let btnSubmit = document.querySelector('#form-submit');
let logout = document.querySelector("#formLogout");

const actualizarImagen = (button) => {
    let data = {
        titulo : button.getAttribute('data-titulo'),
        subtitulo : button.getAttribute('data-subtitulo'),
        dirImagen : button.getAttribute('data-dir'),
        bannerActivo : (button.getAttribute('data-banner') == 1) ? true : false,
        id : button.getAttribute('data-id')
    }
    
    // Mostramos por consola los datos obtenidos
    console.table(data);

    // insertamos los datos en los inputs
    imgPlaceholder.src = data.dirImagen;
    inpTitulo.value = data.titulo;
    inpSubtitulo.value = data.subtitulo;
    inpCheck.checked = data.bannerActivo;
    inpId.value = data.id;

    formulario.action = "controllers/update.image.php";

    btnSubmit.setAttribute('data-evento', 1);
    btnSubmit.textContent = "Actualizar Imagen";
}

const eliminarImagen = (button) => {
    let id = button.getAttribute('data-id');
    let isTrue = confirm('¿Seguro que deseas eliminar esta imagen?')
    if(isTrue){
        fetch(`controllers/delete.image.php?id=${id}`, {
            method:"POST",
        })
        .then(response => response.text())
        .then(res => {
            console.log(res);
            location.reload();
        })
        .catch((err) => {console.log(err)})
    }
}

const enviarActualizar = () => {
    let isTrue = confirm('¿Seguro que deseas actualizar la imagen?')
    if(isTrue){
        formulario.submit();
    }
} 
const enviarNuevaImagen = () => {
    let isTrue = confirm('¿Seguro que deseas guardar la imagen?')
    if(isTrue){
        console.log('enviando imagen...')
        formulario.submit();
    }
} 

inpImg.addEventListener('change', () => {
    let image = inpImg.files[0];
    const reader = new FileReader();

    reader.onload = (e) => {
        imgPlaceholder.src = e.target.result;
    }

    reader.readAsDataURL(image);
})

formulario.addEventListener('submit', (e) => {
    e.preventDefault();
    let evento = btnSubmit.getAttribute('data-evento')
    if(evento == 0){
        enviarNuevaImagen()
    }else{
        enviarActualizar()
    }
})

logout.addEventListener('submit', (e) => {
    e.preventDefault();
    if(confirm("¿Seguro que deseas cerrar sesión?")){
        e.target.submit();
    }
});