<?php 
$host = "localhost";
$name = "beduart";
$user = "root";
$pass = "";

try{

    $conexion = new PDO("mysql:host=$host;dbname=$name",$user,$pass);
    $conexion->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

}catch(PDOException $err){
    
    echo "Error al conectar con la db: " . $err->getMessage();

}