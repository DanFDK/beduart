<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
    <link rel="stylesheet" href="../assets/css/login.css">
    <title>Ingresar al Administrador</title>
</head>
<body style="height: 100vh;" class="w-100 d-flex align-items-center justify-content-center">

<main class="container">
    <section class="card card-login">
        <div class="login-banner text-center">
            <h1>Bienvenido <span class="fw-bold">administrador</span></h1>
            <p>Ingresa tus credencias para ingresar al <span class="fw-bold">panel de control</span></p>
        </div>
        <section class="card-contenido">
            <form action="../controllers/session.login.php" method="POST">
                <div class="mb-3">
                    <label for="" class="form-label">Usuario</label>
                    <input class="form-control" type="text" placeholder="Ingresa tu nombre de usuario" name="usuario" id="usuario">
                </div>
                <div class="mb-3">
                    <label for="" class="form-label">Contraseña</label>
                    <input class="form-control" type="password" placeholder="Ingresa tu contraseña" name="password" id="password">
                </div>
                <button class="mt-3 btn boton-submit">Ingresar al panel</button>
            </form>
        </section>
    </section>
</main>
    
</body>
</html>