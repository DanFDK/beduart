<!DOCTYPE html>
<html lang="es">

<head>
    <title>BEDUART&ensp;|&ensp;CONTACTO</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Beduart es una empresa con mas de 3 años de experiencia dedicada el sector de inmobiliarias.">
    <link rel="shortcut icon" href="../assets/img_inicio/logoBlanco.ico" type="image/x-icon">
    <!-- Default Assets -->
    <link rel="stylesheet" href="../assets/css/footer.css">
    <link rel="stylesheet" href="../assets/css/app.css">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/bootstrap_5.3/css/bootstrap.min.css">
    <!-- AOS animation -->
    <link rel="stylesheet" href="../assets/aos/dist/aos.css">
    
    <script src="../assets/bootstrap_5.3/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/aos/dist/aos.js"></script>
    <script src="../assets/js/navbar_nosotros_servicios_contacto.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <link rel="stylesheet" href="../assets/css/contacto.css">
    <?php
        include('../utils/footer.php');
        include('../utils/navbar_nosotros_servicios_contacto.php')
    ?>
</head>

<body>

    <?php
    navbar();
    ?>

    <section class="portadaCont" data-aos="fade-down" data-aos-duration="1000">
        <h1 data-aos="fade-up" data-aos-duration="2000">CONTÁCTANOS</h1>
    </section>

    <section class="contacto" data-aos="fade" data-aos-duration="1000">
        <div class="contForm">
            <h3 data-aos="fade-right" data-aos-duration="1000">SOLICITAR <span>INFORMACIÓN</span></h3>
            <form id="formulario_contacto">
                <div class="form-floating mb-3" data-aos="fade-right" data-aos-duration="1000">
                    <input type="name" name="nombre" class="form-control border rounded-0 border-primary-subtle" id="nombre">
                    <label for="nombre" class="text-primary-emphasis">Nombre:</label>
                </div>
                <div class="form-floating mb-3" data-aos="fade-left" data-aos-duration="1000">
                    <input type="email" name="correo" class="form-control border rounded-0 border-primary-subtle " id="correo">
                    <label for="correo" class="text-primary-emphasis">Correo: </label>
                </div>
                <div class="form-floating mb-3" data-aos="fade-right" data-aos-duration="1000">
                    <input type="tel" name="telefono" class="form-control border rounded-0 border-primary-subtle " id="telefono">
                    <label for="telefono" class="text-primary-emphasis">Teléfono:</label>
                </div>
                <div class="form-floating" data-aos="fade-left" data-aos-duration="1000">
                    <textarea name="mensaje" class="form-control border rounded-0 border-primary-subtle " placeholder="Leave a comment here" id="mensaje" style="height: 100px"></textarea>
                    <label for="mensaje" class="text-primary-emphasis">Comentarios:</label>
                </div>
                <div class="d-flex justify-content-center p-4 mb-2">
                    <input type="submit" id="submit-contacto" class="fancyBlueButton" style="border-color: #9EC5FE;"></input>
                </div>
            </form>
        </div>

        <div class="contInfo">
            <div class="contInfo__ttl">
                <div data-aos="fade-right" data-aos-duration="1500">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-map-pin" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                        <path d="M9 11a3 3 0 1 0 6 0a3 3 0 0 0 -6 0" />
                        <path d="M17.657 16.657l-4.243 4.243a2 2 0 0 1 -2.827 0l-4.244 -4.243a8 8 0 1 1 11.314 0z" />
                    </svg>
                </div>
                <a href="https://goo.gl/maps/UExiAt8oLr1QuTN87" target="_blank" class="contInfo__texttl">
                    <h4 data-aos="fade-right" data-aos-duration="1500">Ubicación</h4>
                    <p data-aos="fade-left" data-aos-duration="1000">Adolfo López Mateos No. 857, Zona Centro,<span>Zocapú, Míchoacan.</span></p>
                </a>
            </div>
            <div class="contInfo__ttl">
                <div data-aos="fade-right" data-aos-duration="1500">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-brand-whatsapp" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                        <path d="M3 21l1.65 -3.8a9 9 0 1 1 3.4 2.9l-5.05 .9" />
                        <path d="M9 10a.5 .5 0 0 0 1 0v-1a.5 .5 0 0 0 -1 0v1a5 5 0 0 0 5 5h1a.5 .5 0 0 0 0 -1h-1a.5 .5 0 0 0 0 1" />
                    </svg>
                </div>
                <a href="https://api.whatsapp.com/send?phone=5214361040926" target="_blank" class="contInfo__texttl">
                    <h4 data-aos="fade-right" data-aos-duration="1500">WhatsApp</h4>
                    <p data-aos="fade-left" data-aos-duration="1000">(436) 104 0926</p>
                </a>
            </div>
            <div class="contInfo__ttl">
                <div data-aos="fade-right" data-aos-duration="1500">
                    <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-mail" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ffffff" fill="none" stroke-linecap="round" stroke-linejoin="round">
                        <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                        <path d="M3 7a2 2 0 0 1 2 -2h14a2 2 0 0 1 2 2v10a2 2 0 0 1 -2 2h-14a2 2 0 0 1 -2 -2v-10z" />
                        <path d="M3 7l9 6l9 -6" />
                    </svg>
                </div>
                <a href="mailto:admin@beduart.com.mx" target="_blank" class="contInfo__texttl cusm">
                    <h4 data-aos="fade-right" data-aos-duration="1500">Correo eléctronico</h4>
                    <p data-aos="fade-left" data-aos-duration="1000">admin@beduart.com.mx</p>
                </a>
            </div>
        </div>
    </section>

    <section class="amAMap">
        <h5 data-aos="fade-right" data-aos-duration="1000">ESTAMOS <b>CERCA DE TI</b></h5>
        <iframe title="Google ubication maps" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d2433.891604123608!2d-101.78239067164296!3d19.81564902587008!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x842dc93931ab775b%3A0x67391d03290aaaaf!2sAdolfo%20L%C3%B3pez%20Mateos%2C%20Centro%2C%2058600%20Zacapu%2C%20Mich.!5e0!3m2!1ses!2smx!4v1682093504734!5m2!1ses!2smx" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
    </section>

    <?php
    footer();
    ?>
    <script src="../assets/js/email.send.js"></script>
    <script>
        AOS.init();
    </script>
</body>

</html>