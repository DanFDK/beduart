<!DOCTYPE html>
<html lang="es">

<head>
    <title>BEDUART&ensp;|&ensp;NOSOTROS</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Beduart es una empresa con mas de 3 años de experiencia dedicada el sector de inmobiliarias.">
    <link rel="shortcut icon" href="../assets/img_inicio/logoBlanco.ico" type="image/x-icon">
    <!-- Default Assets -->
    <link rel="stylesheet" href="../assets/css/nosotros.css">
    <link rel="stylesheet" href="../assets/css/footer.css">
    <link rel="stylesheet" href="../assets/css/app.css">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/bootstrap_5.3/css/bootstrap.min.css">
    <!-- AOS animation -->
    <link rel="stylesheet" href="../assets/aos/dist/aos.css">

    <script src="../assets/bootstrap_5.3/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/aos/dist/aos.js"></script>
    <script src="../assets/js/navbar_nosotros_servicios_contacto.js"></script>

    <?php
    include('../utils/footer.php');
    include('../utils/navbar_nosotros_servicios_contacto.php')
    ?>
</head>

<body>

    <?php
    navbar();
    ?>

    <section class="portada d-flex vh-100 justify-content-center align-items-center" data-aos="fade-down" data-aos-duration="1000">
        <h1 class="portadaTitulo h1" data-aos="fade-up" data-aos-duration="1500">¿QUIÉNES SOMOS?</h1>
    </section>

    <section class="bannerlogo__nosotros container d-flex justify-content-center align-items-center" data-aos="fade-up" data-aos-duration="1000">
        <picture data-aos="fade-left" data-aos-duration="1000">
            <source class="w-100" media="(min-width: 559px)" srcset="../assets/img_inicio/logoCompleto.webp" type="image/webp">
            <img class="w-100" src="../assets/img_inicio/logoCompleto.webp" alt="logoBeduart">
        </picture>
    </section>

    <section class="shareText container w-100 mb-5">
        <div class="row d-flex flex-column-reverse flex-xl-row">
            <div class="col col-xl-6">
                <picture class="d-flex justify-content-center align-items" data-aos="fade-right" data-aos-duration="1000">
                    <source media="(min-width: 1000px)" srcset="../assets/img_nosotros/templo.webp" type="image/webp">
                    <img class="sImg" src="../assets/img_nosotros/templo.webp" alt="templo">
                </picture>
            </div>

            <div class="sText col col-xl-6 d-flex flex-column justify-content-center align-items-start">
                <h2 class="line h1" data-aos="fade-right" data-aos-duration="1000">BIENVENIDO</h2>
                <span class="fs-5 mb-2" data-aos="fade-right" data-aos-duration="1000">SOMOS TU MEJOR OPCIÓN</span>
                <p class="fs-4" data-aos="fade-right" data-aos-duration="1000">Te ayudamos a encontrar tu propiedade perfecta
                    ya sea tu casa, departamento, terreno, oficina,local
                    o bodega en el centro de zacaapú, Michoacan. <br>
                    Te ofrecemos el mejor servicio inmobiliario o brindándote un
                    servicio personalizado y de calidad para ayudarte con tu
                    búsqueda.
                </p>
            </div>
        </div>
    </section>

    <section class="cardContainer_nosotros row container p-4 mx-0 w-100 mw-100 d-flex flex-column flex-xl-row align-items-xl-start">
        <div class="cardContainer_cardEl p-0 px-5 col vh-lg-40">
            <picture class="d-flex justify-content-center" data-aos="fade-down" data-aos-duration="1000">
                <source class="w-100" srcset="../assets/img_nosotros/mision.webp" type="image/webp">
                <img class="w-100" src="../assets/img_nosotros/mision.webp" class="cardImg" alt="ImgMision">
            </picture>
            <h3 class="h2 " data-aos="fade-right" data-aos-duration="1000">MISIÓN</h3>
            <p class="fs-5" data-aos="fade-left" data-aos-duration="1000">
                Ser la mobiliaria líder del mercado de bienes raíces de Zacapu, Michoacán,
                ofreciendo soluciones inmobiliarias a nuestros clientes e inversionistas
                encontrando siempre la mejor opción a sus necesidades patrimoniales.</p>
        </div>
        <div class="cardContainer_cardEl p-0 px-2 col vh-lg-40">
            <picture class="d-flex justify-content-center" data-aos="fade-down" data-aos-duration="1000">
                <source class="w-100" srcset="../assets/img_nosotros/vision.webp" type="image/webp">
                <img class="w-100" src="../assets/img_nosotros/vision.webp" class="cardImg" alt="ImgVision">
            </picture>
            <h3 class="h2 " data-aos="fade-right" data-aos-duration="1000">VISIÓN</h3>
            <p class="fs-5" data-aos="fade-left" data-aos-duration="1000">Consolidarnos como una de las mejores
                inmobiliarios de Zacapu, Michoacán,
                creciendo junto con nuestros clientes
                e inversionistas.</p>
        </div>
        <div class="cardContainer_cardEl p-0 px-2 col vh-lg-40  valores">
            <picture class="d-flex justify-content-center" data-aos="fade-down" data-aos-duration="1000">
                <source class="w-100" srcset="../assets/img_nosotros/valores.webp" type="image/webp">
                <img class="w-100" src="../assets/img_nosotros/valores.webp" class="cardImg" alt="ImgValores">
            </picture>
            <h3 class="h2" data-aos="fade-right" data-aos-duration="1000">VALORES</h3>
            <p class="fs-5 m-0 d-xxl-flex flex-xxl-column" data-aos="fade-left" data-aos-duration="1000">Confianza, Etica, Seguridad, Solución, <span>Servicio y Inversión.</span></p>            
        </div>
    </section>

    <section class="bannerSolution container ms-0 me-0 mw-100" data-aos="fade" data-aos-duration="2000">
        <h4 class="bannerSolution__white-thin" data-aos="fade-right" data-aos-duration="1000">TE AYUDAMOS A ENCONTRAR LA MEJOR</h4>
        <h4 class="bannerSolution__white-bold" data-aos="fade-left" data-aos-duration="1000">SOLUCIÓN INMOBILIARIA</h4>
        <a class="bannerSolution__Button" href='../assets/Brochure/Brochure.pdf' download="">DESCARGAR BROCHURE</a>
    </section>


    <?php
    footer();
    ?>

    <script>
        AOS.init();
    </script>
</body>

</html>