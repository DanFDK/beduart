<?php 
include_once('../database/conexion.php');
$queryAll = "SELECT * FROM galeria";
$resultGaleria = $conexion->query($queryAll);
$dataGaleria = $resultGaleria->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <title>BEDUART&ensp;|&ensp;SERVICIOS</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Beduart es una empresa con mas de 3 años de experiencia dedicada el sector de inmobiliarias.">
    <link rel="shortcut icon" href="../assets/img_inicio/logoBlanco.ico" type="image/x-icon">
    <!-- Default Assets -->
    <link rel="stylesheet" href="../assets/css/servicios.css">
    <link rel="stylesheet" href="../assets/css/footer.css">
    <link rel="stylesheet" href="../assets/css/app.css">
    <!-- Bootstrap -->
    <link rel="stylesheet" href="../assets/bootstrap_5.3/css/bootstrap.min.css">
    <!-- AOS animation -->
    <link rel="stylesheet" href="../assets/aos/dist/aos.css">

    <script src="../assets/bootstrap_5.3/js/bootstrap.bundle.min.js"></script>
    <script src="../assets/aos/dist/aos.js"></script>
    <script src="../assets/js/navbar_nosotros_servicios_contacto.js"></script>

    <?php
    include('../utils/footer.php');
    include('../utils/navbar_nosotros_servicios_contacto.php')
    ?>
</head>

<body>

    <?php
    navbar();
    ?>

    <section class="portadaSolutions container vh-100 mw-100 d-flex justify-content-center align-items-center" data-aos="fade-down" data-aos-duration="1000">
        <h1 class="portadaSolutions__title" data-aos="fade-up" data-aos-duration="1500">SOLUCIÓNES INTEGRALES</h1>
    </section>

    <section class="bannerLogo container d-flex justify-content-center align-items-center" style="margin: 4rem auto; padding: 0">
        <picture class="d-flex justify-content-center align-items-center" data-aos="fade-down" data-aos-duration="1000">
            <source media="(min-width: 559)" srcset="../assets/img_inicio/logoCompleto.webp" type="image/webp">
            <img class="w-75" src="../assets/img_inicio/logoCompleto.webp" alt="LogoBeduart">
        </picture>
    </section>

    <section class="cardContainer-Services container mw-100 mh-100 p-4 d-flex flex-column flex-xl-row" data-aos="fade" data-aos-duration="1000">
        <div class="cardEl d-flex justify-content-center align-items-center flex-column bg-grey">
            <img class="w-25 mb-4" src="../assets/img_servicios/sell.png" alt="icono de venta" data-aos="fade-down" data-aos-duration="1000">
            <h2 data-aos="fade-left" data-aos-duration="1000">VENTA</h2>
            <p class="fs-5" data-aos="fade-right" data-aos-duration="1000">La venta conlleva hacer un estudio de inmueble y sus alcances.
                Posteriormente, definimos una estrategia de promoción
                a través de los mejores medios de publicidad digitales,
                así como con aliados inmobiliarios y cartera de clientes e inversionistas.</p>
        </div>
        <div class="cardEl d-flex justify-content-center align-items-center flex-column bg-white">
            <img class="w-25 mb-4" src="../assets/img_servicios/rent.png" alt="icono de renta" data-aos="fade-down" data-aos-duration="1000">
            <h2 data-aos="fade-left" data-aos-duration="1000">RENTA</h2>
            <p class="fs-5" data-aos="fade-right" data-aos-duration="1000">Definimos el perfil ideal para rentar el inmueble, filtrando e investigando importantes factores
                como solvencia económica, procesos legales, buro de crédito, fiador o en su caso,
                las garantías pertinentes para un arrendamiento que genere valor a tu patrimonio y éxito.</p>

        </div>
        <div class="cardEl d-flex justify-content-center align-items-center flex-column bg-grey" data-aos="fade" data-aos-duration="1000">
            <img class="w-25 mb-4" src="../assets/img_servicios/management.png" alt="icono de administracion" data-aos="fade-down" data-aos-duration="1000">
            <h2 data-aos="fade-left" data-aos-duration="1000">ADMINISTRACIÓN</h2>
            <p class="fs-5" data-aos="fade-right" data-aos-duration="1000">Administramos el inmueble durante la promoción y el
                arrendamiento del mismo, siempre garantizando la
                renta mensual, no adeudos de servicios en la propiedad a la desocupación,
                revisiones presenciales durante el arrendamiento para reportar
                si hay necesidades de mantenimientos preventivos.</p>
        </div>
    </section>

    <section class="bannerText-CEP container mw-100" data-aos="fade" data-aos-duration="1000">
        <h5 data-aos="fade-right" data-aos-duration="1000">
            CALIDAD, EFICIENCIA Y PROFESIONALISMO
            <div id="linea" class="linea-blanca" data-aos="fade-right" data-aos-duration="1000"></div>
        </h5>
    </section>

    <script>
        window.addEventListener('scroll', () => {
            const elemento = document.getElementById('linea');
            //'getBoundingClientRect()' Obtiene todas  las posiciones en los ejes x,y y en sus lados 
            var rect = elemento.getBoundingClientRect();
            //Obtiene la altura de lo visible en la pantalla
            var windowHeight = window.innerHeight;

            // Verificar si el elemento está visible en la ventana
            if (rect.top < windowHeight) {
                elemento.style.animationPlayState = 'running'; // Mover el elemento a la posición deseada
            }
        });
    </script>

    <section class="bannerPropierties">
        <h4 class="line fs-1" data-aos="fade-right" data-aos-duration="1000">PROPIEDADES <b> DISPONIBLES </b></h4>
    </section>
    
    <section class="grid-elements" id="galeriaImages">
        <!-- ESTOS ELEMENTOS VIENEN DE data.show.js en la carpeta assets/js -->
    </section>
    <section class="w-100 mb-5 d-flex align-items-center justify-content-center" id="paginacion"></section>
    

    <section class="cardContainer-Diferences container p-0 mw-100 flex-row d-flex justify-xl-content-between align-items-xl-start">
        <div class="cardElList p-4">
            <div class="cardBeOne">
                <h1 data-aos="fade-up" data-aos-duration="1000">1</h1>
                <h2 data-aos="fade-up" data-aos-duration="1000">PROYECTOS UNICOS</h2>
            </div>
            <P data-aos="fade-up" data-aos-duration="1000">Nuestros proyectos se diseñan para
                ser verdaderas oportunidades de inversión.</P>
        </div>

        <div class="cardElList p-4">
            <div class="cardBeOne">
                <h1 data-aos="fade-up" data-aos-duration="1000">2</h1>
                <h2 data-aos="fade-up" data-aos-duration="1000">INVERSIÓN SEGURA</h2>
            </div>
            <P data-aos="fade-up" data-aos-duration="1000">Tu patrimonio estará asegurado ya que
                velamos por el beneficio absoluto de nuestros clientes.</P>
        </div>

        <div class="cardElList p-4">
            <div class="cardBeOne">
                <h1 data-aos="fade-up" data-aos-duration="1000">3</h1>
                <h2 data-aos="fade-up" data-aos-duration="1000">COMUNIDAD BEDUART</h2>
            </div>
            <P data-aos="fade-up" data-aos-duration="1000">Creamos relaciones a largo plazo,
                quremos conocer tus necesidades y ayudarte a
                encontrar la mejor opción.</P>
        </div>

    </section>

    <?php
    footer();
    ?>

    <script src="../assets/js/data.show.js"></script>

    <script>
        AOS.init();
    </script>

</body>

</html>