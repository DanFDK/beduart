<?php 
include_once('./database/conexion.php');
$queryAll = "SELECT * FROM galeria WHERE banner = 1";
$resultGaleria = $conexion->query($queryAll);
$dataGaleria = $resultGaleria->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">

<head>
    <title>BEDUART&ensp;|&ensp;INICIO</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Beduart es una empresa con mas de 3 años de experiencia dedicada el sector de inmobiliarias.">
    <link rel="shortcut icon" href="assets/img_inicio/logoComun.ico" type="image/x-icon">
    <!-- Default Assets -->
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/footer.css">
    <link rel="stylesheet" href="assets/css/app.css">

    <!-- Bootstrap -->
    <link rel="stylesheet" href="assets/bootstrap_5.3/css/bootstrap.min.css">
    <!-- AOS animation -->
    <link rel="stylesheet" href="assets/aos/dist/aos.css">
    <!-- Swiper's Styles-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.css" />

    <script src="assets/bootstrap_5.3/js/bootstrap.bundle.min.js"></script>
    <script src="assets/aos/dist/aos.js"></script>
    <script src="assets/js/navbar.js"></script>

    <?php
    include('utils/footer.php');
    include('utils/navbar.php');
    ?>
</head>

<body>

    <?php
    navbar();
    ?>

    <section class="portada" data-aos="fade-down" data-aos-duration="1000">
        <picture>
            <source media="(max-width: 411px)" srcset="assets/img_inicio/logoCompleto.webp" type="image/webp">
            <img src="assets/img_inicio/logoCompleto.webp" alt="logo" data-aos="fade-up" data-aos-duration="2000">
        </picture>
    </section>

    <!-- Servicios -->
    <section class="bigActions">
        <div class="bigActions_text" data-aos="fade-up" data-aos-duration="1000">
            <h4 data-aos="fade-up" data-aos-duration="1000">
                Crecemos con <span>GRANDES ACCIONES</span>
            </h4>
            <span class="grey letter-spacing margin-left">SERVICIOS PROFESIONALES</span>
            <p>Brindamos asesoría personalizada,
                contamos con profesionales en Bienes Raíces,
                ventas y rentas de inmuebles.</br>
                Atendemos a nuestros clientes en
                todo lo relacionado al ámbito Inmobiliario.
            </p>
            <a href="view/servicios.php" class="bigActions_button margin-left letter-spacing d-block" data-aos="fade-right" data-aos-duration="1000">VER MÁS</a>
        </div>
        <picture class="bigActions_img" data-aos="fade-left" data-aos-duration="1000">
            <source media="(min-width: 811px)" srcset="assets/img_inicio/asesores.webp" type="image/webp">
            <img src="assets/img_inicio/asesores.webp" alt="Asesores">
        </picture>
    </section>

    <section class="bannerServices" data-aos="fade" data-aos-duration="1000">
        <h5 data-aos="fade-right" data-aos-duration="1000">SERVICIOS INMOBILIARIOS<span>DE CONFIANZA</span></h5>
    </section>

    <section class="ourServices">
        <picture class="ourServices_img" id="Build" data-aos="fade-right" data-aos-duration="1500">
            <source media="(max-width: 928px)" srcset="assets/img_inicio/edificio.webp" type="image/webp">
            <img src="assets/img_inicio/edificio.webp" alt="edificio">
        </picture>
        <div class="ourServices_text">
            <h4 data-aos="fade-right" data-aos-duration="1000">NUESTROS<span data-aos="fade-right" data-aos-duration="1000">SERVICIOS</span></h4>
            <span class="ourServices_text--small margin-left-ourServices" data-aos="fade-right" data-aos-duration="2000">DIFERENCIADOS POR LA EFECTIVIDAD</span>

            <h5 class="margin-left-ourServices" data-aos="fade-right" data-aos-duration="1500">ADMISTRACIÓN</h5>
            <p class="margin-left-ourServices" data-aos="fade-right" data-aos-duration="2000">Administración de inmuebles en arrendamiento.</p>

            <h5 class="margin-left-ourServices" data-aos="fade-right" data-aos-duration="1500">ASESORÍAS</h5>
            <p class="margin-left-ourServices" data-aos="fade-right" data-aos-duration="2000">Asesoría en compra-venta de arrendamiento o administración de inmueble,
                asesoría para proyectos especiales de bienes raíces, asesoría para Créditos Hipotecarios.
            </p>

            <h5 class="margin-left-ourServices" data-aos="fade-right" data-aos-duration="1500">COMPRA</h5>
            <p class="margin-left-ourServices" data-aos="fade-right" data-aos-duration="2000">Compra de casa habitación, departamento lote de
                terreno habitacional, comercial o industrial, locales comerciales, oficinas, bodegas etc.
            </p>
        </div>
    </section>


    <!-- Propiedades -->

    <section class="discoverProperties">
        <h4 class="discoverProperties_title" data-aos="fade-right" data-aos-duration="1000">DESCUBRE <span>PROPIEDADES</span></h4>

        <div class="swiper mySwiper">
            <div class="swiper-wrapper">
            <?php 
                foreach($dataGaleria as $data){
                    $text1 = $data['titulo'];
                    $text2 = $data['subtitulo'];
                    $dir = $data['dir'];
            ?>    

                <div class="swiper-slide">
                    <p class="swiper-slide__title" data-aos="fade-down" data-aos-duration="1000"><?=$text1?><span><?=$text2?></span></p>
                    <img class="image-slide" src="<?=$dir?>" alt="<?=$text1 . " " . $text2?>">
                </div>
            <?php } ?>    
            </div>
            <div class="swiper-button-prev"></div>
            <div class="swiper-button-next"></div>
        </div>

    </section>


    <!-- Banner -->
    <section class="bannerExperiences" data-aos="fade" data-aos-duration="1000">
        <h5 data-aos="fade-left" data-aos-duration="1000">OTORGAMOS</h5>
        <h5 data-aos="fade-right" data-aos-duration="1000">EXPERIENCIAS EXTRAORDINARIAS</h5>
        <a href="assets/Brochure/Brochure.pdf" data-aos="fade-up" data-aos-duration="1000" download="" class="fancyWhiteButton">DESCARGAR BROCHURE</a>
    </section>

    <?php
    footer();
    ?>

    <script src="https://cdn.jsdelivr.net/npm/swiper@10/swiper-bundle.min.js"></script>
    <script>
        const swiper = new Swiper('.swiper', {
            //loop: true,  Bucle infinito
            //loopedSlides: 3, Número de diapositivas visibles en el carrusel
            effect: 'coverflow', // Efecto 3D Flow
            grabCursor: true, // Cambia el cursor a una mano al pasar sobre el carrusel
            initialSlide: 1, //Número de índice de la diapositiva inicial.
            slidesPerView: 'auto', // Número de diapositivas visibles por vista
            centeredSlides: true, // Centrar las diapositivas en la vista
            coverflowEffect: {
                depth: 600, //Depth offset in px(slides translate in Z axis)
                modifier: 1, //Multiplicador de efectos
                scale: 1, //Efecto Escala de diapositivas
                rotate: 0, //Deslizar girar en grados
                slideShadows: true, //Habilita sombras de diapositivas
                stretch: 0, //Estirar el espacio entre diapositivas (en px)
            },
            navigation: {
                nextEl: '.swiper-button-next', // Selector del botón siguiente
                prevEl: '.swiper-button-prev' // Selector del botón anterior
            }
        });

        var slides = document.querySelectorAll('.swiper-slide');

        for (var i = 0; i < slides.length; i++) {
            var slide = slides[i];
            var p = slide.querySelector('.swiper-slide__title');

            if (slide.classList.contains('swiper-slide-active')) {
                p.style.display = 'flex'; // Mostrar el parrafo del slide activo
            } else {
                p.style.display = 'none'; // Ocultar el parrafo de los demás slides
            }
        }
        swiper.on('transitionStart', () => {
            for (var i = 0; i < slides.length; i++) {
                var slide = slides[i];
                var p = slide.querySelector('.swiper-slide__title');

                if (slide.classList.contains('swiper-slide-active')) {
                    p.style.display = 'flex'; // Mostrar el parrafo del slide activo
                } else {
                    p.style.display = 'none'; // Ocultar el parrafo de los demás slides
                }
            }
        });
    </script>
    <script>
        AOS.init();
    </script>
</body>

</html>