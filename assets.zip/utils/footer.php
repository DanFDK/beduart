<?php
function footer()
{ ?>
    <!-- Footer -->
    <footer>
        <div class="grid-footer">
            <div class="footerLeft">

                <?php
                if (basename($_SERVER['PHP_SELF']) === 'index.php') {
                    // Estás en la página de index
                    echo '<picture class="footer-beduart" data-aos="fade-left" data-aos-duration="1000">
                            <source media="(max-width: 559px)" srcset="assets/img_inicio/logoCompleto.webp" type="image/webp">
                            <img src="assets/img_inicio/logoCompleto.webp" alt="full logo" data-aos="fade-right" data-aos-duration="1000">
                         </picture>';
                } else {
                    // No estás en la página de index
                    echo '<picture class="footer-beduart" data-aos="fade-left" data-aos-duration="1000">
                            <source media="(max-width: 559px)" srcset="../assets/img_inicio/logoCompleto.webp" type="image/webp">
                            <img src="../assets/img_inicio/logoCompleto.webp" alt="full logo" data-aos="fade-right" data-aos-duration="1000">
                         </picture>';
                }
                ?>
                <p data-aos="fade-up" data-aos-duration="1000">BEDUART se distingue por el compromiso y
                    lealtad institucional en favor de nuestros clientes,
                    la busqueda incansable de la excelencia y la innovacion.</p>
            </div>

            <div class="footerCenter">
                <div class="ttl">
                    <?php
                    if (basename($_SERVER['PHP_SELF']) === 'index.php') {
                        // Estás en la página de index
                        echo '<img src="assets/img_inicio/whats.png" alt="logoWhatsApp" data-aos="fade-right" data-aos-duration="1000">';
                    } else {
                        // No estás en la página de index
                        echo '<img src="../assets/img_inicio/whats.png" alt="logoWhatsApp" data-aos="fade-right" data-aos-duration="1000">';
                    }
                    ?>
                    <a href="https://api.whatsapp.com/send?phone=5214361040926" target="_blank" class="texttl">
                        <h6 data-aos="fade-right" data-aos-duration="1000">WhatsApp:</h6>
                        <p data-aos="fade-left" data-aos-duration="1000">(436) 104 0926</p>
                    </a>
                </div>
                <div class="ttl">
                    <div class="svg" data-aos="fade-right" data-aos-duration="1000">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-mail-filled" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ff4500" fill="none" stroke-linecap="round" stroke-linejoin="round" style="color: #2f60a8">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                            <path d="M22 7.535v9.465a3 3 0 0 1 -2.824 2.995l-.176 .005h-14a3 3 0 0 1 -2.995 -2.824l-.005 -.176v-9.465l9.445 6.297l.116 .066a1 1 0 0 0 .878 0l.116 -.066l9.445 -6.297z" stroke-width="0" fill="currentColor" />
                            <path d="M19 4c1.08 0 2.027 .57 2.555 1.427l-9.555 6.37l-9.555 -6.37a2.999 2.999 0 0 1 2.354 -1.42l.201 -.007h14z" stroke-width="0" fill="currentColor" />
                        </svg>
                    </div>
                    <a href="mailto:admin@beduart.com.mx" target="_blank" class="texttl">
                        <h6 data-aos="fade-right" data-aos-duration="1000">Correo eléctronico:</h6>
                        <p data-aos="fade-left" data-aos-duration="1000">admin@beduart.com.mx</p>
                    </a>
                </div>

                <div class="ttl time">
                    <div class="svg" data-aos="fade-right" data-aos-duration="1000">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-clock-filled" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#ff4500" fill="none" stroke-linecap="round" stroke-linejoin="round" style="color: #2f60a8">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                            <path d="M17 3.34a10 10 0 1 1 -14.995 8.984l-.005 -.324l.005 -.324a10 10 0 0 1 14.995 -8.336zm-5 2.66a1 1 0 0 0 -.993 .883l-.007 .117v5l.009 .131a1 1 0 0 0 .197 .477l.087 .1l3 3l.094 .082a1 1 0 0 0 1.226 0l.094 -.083l.083 -.094a1 1 0 0 0 0 -1.226l-.083 -.094l-2.707 -2.708v-4.585l-.007 -.117a1 1 0 0 0 -.993 -.883z" stroke-width="0" fill="currentColor" />
                        </svg>
                    </div>
                    <div class="texttl thorario">
                        <h6 data-aos="fade-right" data-aos-duration="1000">Horario:</h6>
                        <p data-aos="fade-left" data-aos-duration="1000">Lunes a viernes de 9:00 am a 7:00 pm</p>
                    </div>
                </div>

            </div>
            <div class="footerEnd">
                <div class="ttl-location">
                    <div class="ttl-location__MapPin" data-aos="fade-right" data-aos-delay="250" data-aos-duration="1000">
                        <svg xmlns="http://www.w3.org/2000/svg" class="icon icon-tabler icon-tabler-map-pin-filled" width="44" height="44" viewBox="0 0 24 24" stroke-width="1.5" stroke="#2f60a8" stroke-linecap="round" stroke-linejoin="round" style="color: #2f60a8">
                            <path stroke="none" d="M0 0h24v24H0z" fill="none" />
                            <path d="M18.364 4.636a9 9 0 0 1 .203 12.519l-.203 .21l-4.243 4.242a3 3 0 0 1 -4.097 .135l-.144 -.135l-4.244 -4.243a9 9 0 0 1 12.728 -12.728zm-6.364 3.364a3 3 0 1 0 0 6a3 3 0 0 0 0 -6z" stroke-width="0" fill="currentColor" />
                        </svg>
                    </div>
                    <a href="https://goo.gl/maps/UExiAt8oLr1QuTN87" target="_blank" class=" texttl-location">
                        <h6 data-aos="fade-right" data-aos-duration="1000">Ubicación:</h6>
                        <p data-aos="fade-right" data-aos-duration="1000">Calle Herrera y Cairo No. 49, <span>Zona Centro, Zacapu Michoacan</span></p>
                    </a>
                </div>
                <iframe data-aos="fade-right" data-aos-duration="1000" src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d554.8643899680926!2d-103.34180275398316!3d20.683089461559465!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x8428b1ec03155001%3A0x67c91296304d2eab!2sC.%20Ignacio%20Herrera%20y%20Cairo%2049%2C%20Centro%20Barranquitas%2C%2044100%20Guadalajara%2C%20Jal.!5e0!3m2!1ses-419!2smx!4v1688958266327!5m2!1ses-419!2smx" width="600" height="450" style="border: 2px solid #cacaca;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
        </div>
        <div class="footerBottom">
            <p>Copyright &copy; 2023 BEDUART Grupo Inmobiliario</p>
        </div>
    </footer>
<?php
}
?>