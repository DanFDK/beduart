<?php
function navbar()
{
?>

  <!-- Navegacion Principal -->
  <nav class="navbar navbar-expand-lg bg-transparent position-fixed top-0">
    <div class="container-md d-flex justify-content-between">
      <a class="navbar-brand" href="index.php"><img src="../assets/img_inicio/logoBlanco.webp" ; data-aos="fade-right" data-aos-duration="2000" alt="Short logo"></a>
      <button class="navbar-toggler border border-0" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="border border-0"><img src="../assets/img_inicio/menu.png" alt="menu"></span>
      </button>
      <div class="collapse navbar-collapse ms-5" id="navbarNav">
        <ul class="navbar-nav" data-aos="fade-down" data-aos-duration="1000">
          <li class="nav-item">
            <a class="nav-link mx-3 white" aria-current="page" href="../index.php">INICIO</a>
          </li>
          <li class="nav-item">
            <a class="nav-link mx-3 white" href="nosotros.php">NOSOTROS</a>
          </li>
          <li class="nav-item">
            <a class="nav-link mx-3 white" href="servicios.php">SERVICIOS</a>
          </li>
          <li class="nav-item">
            <a class="nav-link mx-3 white" href="contacto.php">CONTACTO</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

<?php
}
?>