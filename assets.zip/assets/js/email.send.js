let formulario = document.querySelector('#formulario_contacto');
let nombre = document.querySelector('#nombre');
let correo = document.querySelector('#correo');
let telefono = document.querySelector('#telefono');
let mensaje = document.querySelector('#mensaje');


let expRegs = {
    nombre: /^[A-Za-zÁÉÍÓÚáéíóúñÑ\s]+$/u,
    correo: /^[\w.-]+@[a-zA-Z\d.-]+\.[a-zA-Z]{2,}$/i,
    telefono: /^\+?[0-9]{10,}(?:[ -][0-9]+)*$/
}

const enviarFormulario = (formData) => {
    fetch('../controllers/email.send.php', {
        method: "POST",
        body: formData
    })
    .then(response => response.text())
    .then(res => {
        if(res === "false"){
            Swal.fire({
                icon: 'error',
                title: 'Oops!',
                text: '¡Lo sentimos!, hubo un problema al enviar el mensaje',
                showConfirmButton: false,
                timer: 2500
            })
            return
        }else{
            formulario.reset();
            Swal.fire({
                icon: 'success',
                title: 'Listo',
                text: 'Tu mensaje fue enviado correctamente',
                showConfirmButton: false,
                timer: 2500
            })
            return
        }
    })
}


formulario.addEventListener('submit', (e) => {

    e.preventDefault();
    
    if(!nombre.value || !correo.value || !telefono.value || !mensaje.value){
        Swal.fire({
            title: 'Campos vacios',
            icon: 'warning',
            timer: 2500,
            showConfirmButton: false,
            text: "Para poder enviar el mensaje es importante completar todos los campos."
        });
    }
    else if(!expRegs.nombre.test(nombre.value)){
        Swal.fire({
            title: 'Nombre invalido',
            icon: 'warning',
            timer: 2500,
            showConfirmButton: false,
            text: "En el campo nombre solo puedes incluir letras, no se permiten otros carácteres"
        });
        nombre.focus();
    }
    else if(!expRegs.correo.test(correo.value)){
        Swal.fire({
            title: 'Correo invalido',
            icon: 'warning',
            timer: 2500,
            showConfirmButton: false,
            text: "El formato del correo que ingresaste no es valido. Un correo debe lucir de la siguiente manera: correo@example.com."
        });
        correo.focus();
    }
    else if(!expRegs.telefono.test(telefono.value)){
        Swal.fire({
            title: 'Teléfono invalido',
            icon: 'warning',
            timer: 2500,
            showConfirmButton: false,
            text: "El número de telefono no es un número valido; en este campo solo puedes añadir números, si estas añadiendo guiones o simbolos borralos."
        });
        telefono.focus();
    }else{
        let formData = new FormData(formulario);
        enviarFormulario(formData);
    }
    

});