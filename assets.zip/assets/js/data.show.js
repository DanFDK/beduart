let container = document.querySelector('#galeriaImages')
let paginador = document.querySelector('#paginacion')
let cantImages = 3;
let paginaActual = 1;
let url = `../controllers/data.show.php?cant=${cantImages}`;


const createCardImage = (dir,alt,titulo,subtitulo) => {
  const divElement = document.createElement("div");
  divElement.classList.add("g-element", "ratio", "ratio-1x1");
  divElement.setAttribute("data-aos", "fade-right");
  divElement.setAttribute("data-aos-duration", "1500");

  const pictureElement = document.createElement("picture");

  const sourceElement = document.createElement("source");
  sourceElement.setAttribute("media", "(min-width: 526px)");
  sourceElement.setAttribute("srcset", dir);
  sourceElement.setAttribute("type", "image/webp");

  const imgElement = document.createElement("img");
  imgElement.setAttribute("src", dir);
  imgElement.setAttribute("id", "img-6");
  imgElement.setAttribute("alt", alt);

  const labelElement = document.createElement("label");
  labelElement.classList.add("fs-4");
  labelElement.setAttribute("for", "img-6");
  labelElement.textContent = titulo;

  const smallElement = document.createElement("small");
  smallElement.classList.add("fs-6");
  smallElement.setAttribute(
    "style",
    "font-family: 'EuclidCircular_Light', Arial, Helvetica, sans-serif;"
  );
  smallElement.textContent = subtitulo;

  // Construir la estructura HTML
  labelElement.appendChild(smallElement);
  pictureElement.appendChild(sourceElement);
  pictureElement.appendChild(imgElement);
  pictureElement.appendChild(labelElement);
  divElement.appendChild(pictureElement);

  // Agregar el elemento al contenedor
  container.appendChild(divElement);
};


const mostrarRegistros = async(url) => {
    const results = await fetch(url);
    const data = await results.json();
    const buttons = document.querySelectorAll('.btnPage')
    buttons.forEach( btn => {
        if(btn.textContent === paginaActual){
            console.log(btn.textContent);
        }
    })
    console.table(data);

    data.forEach(e => {
        const dir = `../${e.dir}`;
        const alt = `Fotografía de ${e.titulo}, ${e.subtitulo}`;
        const titulo = e.titulo;
        const subtitulo = e.subtitulo;

        createCardImage(dir,alt,titulo,subtitulo);
    });
}

const pages = async () => {
    const results = await fetch(`../controllers/data.show.php?cant=${cantImages}&pages=true`)
    const cant = await results.json();
    if(cant > 1){
        for(let i = 0; i < cant; i++){
            let numero = i + 1
            let button = document.createElement('button')
            button.classList.add('btnPage', 'btn')
            button.setAttribute('pagina', numero)
            button.textContent = numero
            
            button.addEventListener('click', () => {
                container.textContent = ''
                paginaActual = numero
                console.log(paginaActual)
                url = `../controllers/data.show.php?cant=${cantImages}&page=${numero}`
                mostrarRegistros(url)
            })
            paginador.appendChild(button)
        }
    }
}

mostrarRegistros(url);
pages();