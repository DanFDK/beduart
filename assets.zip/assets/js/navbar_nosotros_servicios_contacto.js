window.addEventListener("scroll", () => {
  const menu = document.querySelector(".navbar");
  const scrollPosY = window.scrollY;
  const isScrollPastThreshold = scrollPosY > 300;
  
  menu.classList.toggle("bg-transparent", !isScrollPastThreshold);
  menu.classList.toggle("transparentBlack", isScrollPastThreshold);
});
