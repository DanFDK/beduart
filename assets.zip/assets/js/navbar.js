window.addEventListener("scroll", () => {
  const elementos = document.querySelectorAll(".nav-link");
  const menu = document.querySelector(".navbar");
  const scrollPosY = window.scrollY;
  const isScrollPastThreshold = scrollPosY > 300;

  menu.classList.toggle("bg-transparent", !isScrollPastThreshold);
  menu.classList.toggle("transparentBlack", isScrollPastThreshold);

  elementos.forEach((element) => {
    element.classList.toggle("black", !isScrollPastThreshold);
    element.classList.toggle("white", isScrollPastThreshold);
  });
});


